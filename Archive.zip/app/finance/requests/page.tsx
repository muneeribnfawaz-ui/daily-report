import { redirect } from "next/navigation";
import Link from "next/link";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DashboardPageHeader } from "@/components/dashboard/ui";
import { getCurrentUser } from "@/lib/auth";
import { canViewFinanceReport } from "@/lib/permissions";
import { connectToDatabase } from "@/lib/db";
import FinanceReport from "@/models/FinanceReport";
import { DollarSign, FileText, ArrowRight, Clock, CheckCircle2, XCircle } from "lucide-react";

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

function formatSAR(amount: number): string {
  return `${amount.toLocaleString("en-US", { minimumFractionDigits: 0 })} SAR`;
}

function formatDate(value: Date | string) {
  return new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" }).format(new Date(value));
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, { className: string; label: string; icon: any }> = {
    pending: {
      className: "border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-600 dark:bg-amber-950/50 dark:text-amber-300",
      label: "Pending",
      icon: Clock
    },
    approved: {
      className: "border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-300",
      label: "Approved",
      icon: CheckCircle2
    },
    rejected: {
      className: "border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-600 dark:bg-rose-950/50 dark:text-rose-300",
      label: "Rejected",
      icon: XCircle
    }
  };
  const v = variants[status] || variants.pending;
  const Icon = v.icon;
  return (
    <Badge className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${v.className}`}>
      <Icon className="h-3 w-3" />
      <span>{v.label}</span>
    </Badge>
  );
}

export default async function MoneyRequestsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!canViewFinanceReport(user)) redirect("/dashboard");

  await connectToDatabase();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const reports = await FinanceReport.find({
    nextDayApprovals: { $exists: true, $not: { $size: 0 } }
  })
    .sort({ reportDate: -1 })
    .limit(50)
    .lean() as Array<Record<string, any>>;

  type RequestItem = {
    reportId: string;
    reportDate: Date | string;
    submittedByName: string;
    particulars: string;
    amountINR: number;
    amountRiyal: number;
    reason: string;
    approval: string;
  };

  const requestsList: RequestItem[] = [];

  for (const report of reports) {
    if (Array.isArray(report.nextDayApprovals)) {
      for (const item of report.nextDayApprovals) {
        requestsList.push({
          reportId: String(report._id),
          reportDate: report.reportDate,
          submittedByName: report.submittedByName || "Finance User",
          particulars: item.particulars || "N/A",
          amountINR: item.amountINR || 0,
          amountRiyal: item.amountRiyal || 0,
          reason: item.reason || "",
          approval: item.approval || report.status || "pending"
        });
      }
    }
  }

  const totalAmountINR = requestsList.reduce((acc, r) => acc + (r.amountINR || 0), 0);
  const pendingCount = requestsList.filter((r) => r.approval === "pending").length;

  return (
    <AppShell title="Money Requests" role={user.role}>
      <div className="space-y-6">
        <DashboardPageHeader
          eyebrow="Finance"
          title="Money Requests"
          description="View and manage next-day money approval requests submitted by the finance department."
          actions={
            <Button asChild variant="outline">
              <Link href="/finance">View All Reports</Link>
            </Button>
          }
        />

        {/* Stats Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-cardBorder bg-card p-4 shadow-soft">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
                <DollarSign className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Total Money Requested</div>
                <div className="text-xl font-bold tabular-nums text-foreground">{formatCurrency(totalAmountINR)}</div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-cardBorder bg-card p-4 shadow-soft">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Pending Requests</div>
                <div className="text-xl font-bold tabular-nums text-foreground">{pendingCount}</div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-cardBorder bg-card p-4 shadow-soft">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Total Items</div>
                <div className="text-xl font-bold tabular-nums text-foreground">{requestsList.length}</div>
              </div>
            </div>
          </div>
        </div>

        {requestsList.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 p-12 text-center">
            <FileText className="h-12 w-12 text-muted-foreground/40" />
            <h3 className="mt-4 text-lg font-semibold">No Money Requests</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              No money requests or next-day approvals have been submitted yet.
            </p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-cardBorder bg-card shadow-soft">
            {/* Table Header */}
            <div className="hidden border-b bg-muted/30 px-4 py-3 sm:grid sm:grid-cols-[1.5fr_1fr_1fr_1fr_1fr_auto] sm:gap-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Particulars / Reason</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Submitted By</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Amount (INR / SAR)</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Status</div>
              <div className="w-10" />
            </div>

            {/* Table Rows */}
            {requestsList.map((req, idx) => (
              <Link
                key={`${req.reportId}-${idx}`}
                href={`/finance/${req.reportId}`}
                className="flex flex-col gap-2 border-b px-4 py-3.5 transition-colors hover:bg-accent/20 sm:grid sm:grid-cols-[1.5fr_1fr_1fr_1fr_1fr_auto] sm:items-center sm:gap-4 last:border-b-0"
              >
                <div>
                  <div className="font-medium text-sm text-foreground">{req.particulars}</div>
                  {req.reason ? <div className="text-xs text-muted-foreground">{req.reason}</div> : null}
                </div>
                <div className="text-sm text-muted-foreground">
                  {req.submittedByName}
                </div>
                <div className="text-sm text-muted-foreground">
                  {formatDate(req.reportDate)}
                </div>
                <div className="text-sm font-semibold tabular-nums text-right">
                  <div>{formatCurrency(req.amountINR)}</div>
                  {req.amountRiyal > 0 ? (
                    <div className="text-xs text-muted-foreground font-normal">{formatSAR(req.amountRiyal)}</div>
                  ) : null}
                </div>
                <div className="flex sm:justify-center">
                  <StatusBadge status={req.approval} />
                </div>
                <div className="flex justify-end">
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
