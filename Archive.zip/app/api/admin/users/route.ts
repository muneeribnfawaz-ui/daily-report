import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import User from "@/models/User";
import WorkspaceMember from "@/models/WorkspaceMember";
import { adminCreateUserSchema } from "@/lib/validation";
import { hashPassword } from "@/lib/auth";
import { getActiveTeamTypeNames, getActiveTeamTypeShowNameMap } from "@/lib/team-types";
import { getUserTeamLabel, sortUsersForDirectory } from "@/lib/user-directory-sort";
import { ApiResponse } from "@/lib/api-response";
import { authorizeApi } from "@/lib/api-auth";

import TeamType from "@/models/TeamType";

function normalizeTeamNames(teamName?: string | null, teamNames?: string[] | null) {
  const values = [teamName, ...(teamNames ?? [])]
    .map((value) => value?.trim())
    .filter((value): value is string => Boolean(value));

  return Array.from(new Set(values));
}

export async function GET(request: Request) {
  const auth = await authorizeApi(["admin", "ceo", "hod", "report_manager", "team_lead"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  const url = new URL(request.url);
  const search = url.searchParams.get("search")?.trim();
  const role = url.searchParams.get("role");
  const status = url.searchParams.get("status");
  const selectedDept = url.searchParams.get("department") || request.headers.get("x-department");
  let workspaceId = url.searchParams.get("workspaceId") || request.headers.get("x-workspace-id");
  if (!workspaceId && user.role === "ceo") {
    workspaceId = "all";
  }
  if (!workspaceId && user.role !== "admin" && role !== "ceo") {
    workspaceId = user.workspaceId;
  }
  if (!workspaceId && user.role !== "admin" && role !== "ceo") {
    return ApiResponse.validationError("workspaceId is required");
  }

  await connectToDatabase();
  const teamTypeShowNameMap = await getActiveTeamTypeShowNameMap();

  const filter: Record<string, any> = {};
  if (role) filter.role = role;
  if (status) filter.status = status;

  if (user.role !== "admin") {
    const memberships = await WorkspaceMember.find({
      userId: user.id,
      status: "active",
      isActive: true
    }).select("workspaceId").lean() as any[];
    const allowedWorkspaceIds = memberships.map(m => String(m.workspaceId));

    if (user.role === "ceo") {
      const { default: Workspace } = await import("@/models/Workspace");
      const ceoIdentifiers = [user.name, user.email].filter(Boolean);
      const createdWorkspaces = ceoIdentifiers.length > 0 
        ? await Workspace.find({ createdBy: { $in: ceoIdentifiers }, isDeleted: { $ne: true } }).select("_id").lean() as any[]
        : [];
      
      for (const cw of createdWorkspaces) {
        const cwId = String(cw._id);
        if (!allowedWorkspaceIds.includes(cwId)) {
          allowedWorkspaceIds.push(cwId);
        }
      }
    }

    if (workspaceId && workspaceId !== "all") {
      filter.workspaceId = allowedWorkspaceIds.includes(workspaceId) ? workspaceId : "non_existent_id";
    } else {
      filter.workspaceId = { $in: allowedWorkspaceIds };
    }
  } else {
    if (workspaceId && workspaceId !== "all") {
      filter.workspaceId = workspaceId;
    }
  }

  // We find WorkspaceMembers and populate the User document
  const members = await WorkspaceMember.find(filter).populate("userId").sort({ createdAt: -1 }).lean() as any[];

  // Fetch global executive users (admin, ceo) who do not have WorkspaceMember records
  // Only display them for Admin users, since CEO only sees their own workspace items.
  const executiveFilter: Record<string, unknown> = {
    role: { $in: ["admin", "ceo"] },
    isDeleted: { $ne: true }
  };
  if (role && (role === "admin" || role === "ceo")) {
    executiveFilter.role = role;
  }
  const executiveUsers = (user.role === "admin" && (!workspaceId || workspaceId === "all") && (!role || role === "admin" || role === "ceo"))
    ? await User.find(executiveFilter).lean() as any[]
    : [];

  // Flatten the member and user data for the frontend, ensuring uniqueness by user ID
  const usersMap = new Map<string, any>();

  for (const m of members) {
    if (!m.userId || !m.userId._id) continue;
    const u = m.userId;
    const userIdStr = String(u._id);
    if (!usersMap.has(userIdStr)) {
      usersMap.set(userIdStr, {
        _id: u._id,
        memberId: m._id,
        name: u.name,
        firstName: u.firstName,
        lastName: u.lastName,
        email: u.email,
        phone: u.phone,
        avatarUrl: u.avatarUrl,
        empID: m.empID,
        role: m.role || u.role,
        roleTypes: m.roleTypes || [],
        teamName: m.teamName || m.teamNames?.[0] || null,
        teamNames: m.teamNames && m.teamNames.length ? m.teamNames : (m.teamName ? [m.teamName] : []),
        departments: m.departments || [],
        managerName: m.managerName || "",
        status: m.status || "active",
        isActive: m.isActive
      });
    }
  }

  for (const execUser of executiveUsers) {
    const execUserIdStr = String(execUser._id);
    if (!usersMap.has(execUserIdStr)) {
      usersMap.set(execUserIdStr, {
        _id: execUser._id,
        memberId: execUser._id,
        name: execUser.name,
        firstName: execUser.firstName || "",
        lastName: execUser.lastName || "",
        email: execUser.email,
        phone: execUser.phone || "",
        avatarUrl: execUser.avatarUrl || "",
        empID: "EXEC",
        role: execUser.role || "admin",
        roleTypes: [],
        teamName: null,
        teamNames: [],
        departments: [],
        managerName: "",
        status: "active",
        isActive: true
      });
    }
  }

  let users = Array.from(usersMap.values());

  if (user.role === "hod") {
    const hodAccessibleDepts = (user.departments?.map((d: any) => d.name) ?? []).filter(Boolean);
    if (selectedDept && selectedDept !== "all") {
      const effectiveDept = hodAccessibleDepts.length > 0
        ? (hodAccessibleDepts.includes(selectedDept) ? selectedDept : "non_existent_dept")
        : selectedDept;
      users = users.filter((u) => u.departments?.some((d: any) => d.name === effectiveDept));
    } else if (hodAccessibleDepts.length > 0) {
      users = users.filter((u) => u.departments?.some((d: any) => hodAccessibleDepts.includes(d.name)));
    }
  }

  if (search) {
    const searchRegex = new RegExp(search, "i");
    users = users.filter(
      (u) =>
        searchRegex.test(u.name || "") ||
        searchRegex.test(u.email || "") ||
        searchRegex.test(u.empID || "") ||
        searchRegex.test(u.managerName || "")
    );
  }

  const sortedUsers = sortUsersForDirectory(users);
  const usersWithDisplayTeam = sortedUsers.map((currentUser: any) => ({
    ...currentUser,
    displayTeamName: getUserTeamLabel(currentUser, teamTypeShowNameMap)
  }));

  return ApiResponse.success(usersWithDisplayTeam, "Users directory fetched successfully");
}

export async function POST(request: Request) {
  const auth = await authorizeApi(["admin", "ceo", "hod", "report_manager", "team_lead"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  const body = await request.json();
  const parsed = adminCreateUserSchema.safeParse(body);
  if (!parsed.success) {
    return ApiResponse.validationError("Invalid user payload", parsed.error.format());
  }

  await connectToDatabase();

  const allowedRolesForUserRole: Record<string, string[]> = {
    admin: ["admin", "ceo", "hod", "report_manager", "team_lead", "team_member"],
    ceo: ["hod", "report_manager", "team_lead", "team_member"],
    hod: ["report_manager", "team_lead", "team_member"],
    report_manager: ["team_lead", "team_member"],
    team_lead: ["team_member"]
  };

  const creatorRole = user.role;
  const targetRole = parsed.data.role;
  const allowedRolesToCreate = allowedRolesForUserRole[creatorRole] ?? [];

  if (!allowedRolesToCreate.includes(targetRole)) {
    return ApiResponse.forbidden(`Users with role '${creatorRole}' cannot create '${targetRole}' accounts.`);
  }

  // Workspace permission check for non-admin users
  let targetWorkspaceId = parsed.data.workspaceId;
  if (!targetWorkspaceId || targetWorkspaceId === "all") {
    targetWorkspaceId = user.workspaceId;
  }

  if (user.role !== "admin" && targetRole !== "ceo" && targetRole !== "admin") {
    if (targetWorkspaceId && targetWorkspaceId !== "all") {
      let hasMembership = await WorkspaceMember.findOne({
        userId: user.id,
        workspaceId: targetWorkspaceId,
        status: "active",
        isActive: true
      }).lean();

      if (!hasMembership && user.role === "ceo") {
        const { default: Workspace } = await import("@/models/Workspace");
        const ceoWorkspace = await Workspace.findOne({
          _id: targetWorkspaceId,
          isDeleted: { $ne: true }
        }).lean();

        if (ceoWorkspace) {
          await WorkspaceMember.create({
            workspaceId: targetWorkspaceId,
            userId: user.id,
            role: "ceo",
            status: "active",
            isActive: true,
            createdBy: user.name || "System"
          });
          hasMembership = true as any;
        }
      }

      if (!hasMembership) {
        return ApiResponse.forbidden("You do not have access to manage this workspace.");
      }
    }
  }

  const validTeamNames = await getActiveTeamTypeNames();
  const existingUser = await User.findOne({ email: parsed.data.email.toLowerCase() }).lean();
  if (existingUser) {
    return ApiResponse.error("A user with this email already exists", 2002, 409);
  }

  const existingPhone = await User.findOne({ phone: parsed.data.phone }).lean();
  if (existingPhone) {
    return ApiResponse.error("A user with this phone number already exists", 2003, 409);
  }

  let allowedTeamNames = validTeamNames;
  if (parsed.data.role === "team_member" && parsed.data.managerName) {
    const managerUser = await User.findOne({ name: parsed.data.managerName }).lean();
    if (managerUser) {
      const managerMember = await WorkspaceMember.findOne({
        userId: (managerUser as any)._id,
        role: { $in: ["team_lead", "report_manager", "hod", "admin"] }
      }).lean() as any;
      if (managerMember?.departments?.length) {
        const deptNames = managerMember.departments.map((d: any) => d.name);
        const deptTeams = await TeamType.find({ department: { $in: deptNames }, isActive: true, isDeleted: false }).lean();
        allowedTeamNames = deptTeams.map((t: any) => t.name);
      }
    }
  }

  if (parsed.data.role === "team_member" && allowedTeamNames.length === 0) {
    return ApiResponse.validationError("Selected team lead has no assigned teams or departments");
  }

  const invalidTeamName = parsed.data.teamNames.find((teamName) => !validTeamNames.includes(teamName));
  if (invalidTeamName) {
    return ApiResponse.validationError(`Unknown team type: ${invalidTeamName}`);
  }

  const invalidLeadTeamName = parsed.data.role === "team_member" ? parsed.data.teamNames.find((teamName) => !allowedTeamNames.includes(teamName)) : null;
  if (invalidLeadTeamName) {
    return ApiResponse.validationError(`Selected team is not managed by the chosen team lead: ${invalidLeadTeamName}`);
  }

  const password = await hashPassword(parsed.data.password);
  const fullName = `${parsed.data.firstName} ${parsed.data.lastName}`.trim();

  const isExecutive = parsed.data.role === "admin" || parsed.data.role === "ceo";

  // 1. Create global User
  const newUser = await User.create({
    name: fullName,
    firstName: parsed.data.firstName,
    lastName: parsed.data.lastName,
    phone: parsed.data.phone,
    email: parsed.data.email.toLowerCase(),
    password,
    role: parsed.data.role,
    roleTypes: parsed.data.roleTypes ?? [],
    teamNames: parsed.data.teamNames ?? [],
    teamName: parsed.data.teamNames?.[0] ?? "",
    departments: parsed.data.departments ?? [],
    managerName: parsed.data.managerName ?? "",
    isDeleted: false,
    isAdminActive: isExecutive,
    isEmailActivated: false
  });

  targetWorkspaceId = parsed.data.workspaceId || targetWorkspaceId;

  // Auto-create workspace for CEO
  if (parsed.data.role === "ceo") {
    const { default: Workspace } = await import("@/models/Workspace");
    const workspaceName = `${fullName} CEO Workspace`.trim();
    const newWorkspace = await Workspace.create({
      name: workspaceName,
      type: "ceo",
      isActive: true,
      createdBy: user.id
    });
    targetWorkspaceId = newWorkspace._id.toString();
  }

  // 2. Create WorkspaceMember if workspaceId is provided or auto-created
  if (targetWorkspaceId && targetWorkspaceId.trim() !== "") {
    const newMember = await WorkspaceMember.create({
      userId: newUser._id,
      workspaceId: targetWorkspaceId,
      empID: parsed.data.empID || "EMP",
      role: parsed.data.role,
      roleTypes: parsed.data.roleTypes ?? [],
      teamNames: parsed.data.teamNames ?? [],
      teamName: parsed.data.teamNames?.[0] ?? "",
      departments: parsed.data.departments ?? [],
      managerName: parsed.data.managerName ?? "",
      status: "active",
      isActive: true
    });

    return ApiResponse.created({ ...newUser.toObject(), ...newMember.toObject() }, "User created successfully");
  }

  return ApiResponse.created(newUser.toObject(), "User created successfully");
}
