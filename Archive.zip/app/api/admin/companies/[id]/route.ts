import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import Workspace from "@/models/Workspace";
import { workspaceUpdateSchema } from "@/lib/validation";
import { ApiResponse } from "@/lib/api-response";
import { authorizeApi } from "@/lib/api-auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: RouteContext) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;

  const { id } = await context.params;
  await connectToDatabase();

  const workspace = await Workspace.findById(id).lean();
  if (!workspace || (workspace as any).isDeleted) {
    return ApiResponse.error("Workspace not found", 4004, 404);
  }

  return ApiResponse.success(workspace, "Company fetched successfully");
}

export async function PUT(request: Request, context: RouteContext) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  const { id } = await context.params;
  const body = await request.json();
  await connectToDatabase();

  const workspace = await Workspace.findById(id);
  if (!workspace || workspace.isDeleted) {
    return ApiResponse.notFound("Workspace not found");
  }

  // Auto-resolve ownerWorkspaceId for CEO on update if missing
  if (user.role === "ceo" && (!body.ownerWorkspaceId || body.ownerWorkspaceId.trim() === "")) {
    const ceoOwnerWorkspace = await Workspace.findOne({
      type: "ceo",
      isDeleted: { $ne: true },
      createdBy: { $in: [user.name, user.email].filter(Boolean) }
    }).lean();

    if (ceoOwnerWorkspace) {
      body.ownerWorkspaceId = String(ceoOwnerWorkspace._id);
    } else {
      const newCeoWs = await Workspace.create({
        name: `${user.name || "CEO"} Owner Workspace`,
        type: "ceo",
        isActive: true,
        createdBy: user.name || user.email
      });
      body.ownerWorkspaceId = String(newCeoWs._id);
    }
  }

  const parsed = workspaceUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return ApiResponse.validationError("Invalid payload", parsed.error.format());
  }

  if (parsed.data.name && parsed.data.name.trim().toLowerCase() !== workspace.name.toLowerCase()) {
    const existing = await Workspace.findOne({
      _id: { $ne: id },
      name: { $regex: new RegExp(`^${parsed.data.name.trim()}$`, "i") },
      isDeleted: { $ne: true }
    });
    if (existing) {
      return ApiResponse.error("A workspace with this name already exists", 4009, 400);
    }
    workspace.name = parsed.data.name.trim();
  }

  if (parsed.data.code !== undefined) workspace.code = parsed.data.code.trim().toUpperCase();
  if (parsed.data.type !== undefined) workspace.type = parsed.data.type;
  if (parsed.data.ownerWorkspaceId !== undefined) workspace.ownerWorkspaceId = parsed.data.ownerWorkspaceId;
  if (parsed.data.description !== undefined) workspace.description = parsed.data.description.trim();
  if (parsed.data.isActive !== undefined) workspace.isActive = parsed.data.isActive;

  await workspace.save();
  return ApiResponse.success(workspace, "Workspace updated successfully");
}

export async function DELETE(_request: Request, context: RouteContext) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;

  const { id } = await context.params;
  await connectToDatabase();

  const workspace = await Workspace.findById(id);
  if (!workspace || workspace.isDeleted) {
    return ApiResponse.notFound("Workspace not found");
  }

  workspace.isDeleted = true;
  await workspace.save();

  return ApiResponse.success(null, "Workspace deleted successfully");
}
