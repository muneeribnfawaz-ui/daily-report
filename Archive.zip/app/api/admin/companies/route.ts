import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import Workspace from "@/models/Workspace";
import { workspaceSchema } from "@/lib/validation";
import { ApiResponse } from "@/lib/api-response";
import { authorizeApi } from "@/lib/api-auth";

import User from "@/models/User";
import WorkspaceMember from "@/models/WorkspaceMember";

export async function GET(request: Request) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  const url = new URL(request.url);
  const ceoId = url.searchParams.get("ceoId") || url.searchParams.get("workspaceId") || request.headers.get("x-workspace-id");

  await connectToDatabase();
  const filter: any = { isDeleted: { $ne: true }, type: { $ne: "ceo" } };

  if (user.role === "ceo") {
    const memberships = await WorkspaceMember.find({
      userId: user.id,
      status: "active",
      isActive: true
    }).select("workspaceId").lean() as any[];
    const workspaceIds = memberships.map((m) => m.workspaceId);
    
    const ceoIdentifiers = [user.name, user.email].filter(Boolean);
    filter.$or = [
      { _id: { $in: workspaceIds } },
      ...(ceoIdentifiers.length > 0 ? [{ createdBy: { $in: ceoIdentifiers } }] : [])
    ];
  } else if (user.role === "admin" && ceoId && ceoId !== "all" && ceoId.trim() !== "") {
    const ceoUser = await User.findById(ceoId).lean() as any;
    if (ceoUser && ceoUser.role === "ceo") {
      const memberships = await WorkspaceMember.find({
        userId: ceoId,
        status: "active",
        isActive: true
      }).select("workspaceId").lean() as any[];
      const workspaceIds = memberships.map((m) => m.workspaceId);
      filter._id = { $in: workspaceIds };
    } else {
      filter._id = ceoId;
    }
  }

  const workspaces = await Workspace.find(filter)
    .sort({ createdAt: -1 })
    .lean();

  return ApiResponse.success(workspaces, "Companies fetched successfully");
}

export async function POST(request: Request) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  await connectToDatabase();
  const body = await request.json();
  const url = new URL(request.url);
  const ceoId = url.searchParams.get("ceoId") || url.searchParams.get("workspaceId") || request.headers.get("x-workspace-id");

  // Auto-resolve ownerWorkspaceId BEFORE validation for company type workspaces
  if ((body.type ?? "company") === "company" && (!body.ownerWorkspaceId || body.ownerWorkspaceId.trim() === "")) {
    if (user.role === "ceo") {
      const ceoOwnerWorkspace = await Workspace.findOne({
        type: "ceo",
        isDeleted: { $ne: true },
        createdBy: { $in: [user.name, user.email].filter(Boolean) }
      }).lean();

      if (ceoOwnerWorkspace) {
        body.ownerWorkspaceId = String(ceoOwnerWorkspace._id);
      } else {
        const newCeoWs = await Workspace.create({
          name: `${user.name || "CEO"} Owner Workspace`,
          type: "ceo",
          isActive: true,
          createdBy: user.name || user.email
        });
        body.ownerWorkspaceId = String(newCeoWs._id);
      }
    } else if (user.role === "admin" && ceoId && ceoId !== "all" && ceoId.trim() !== "") {
      const ceoUser = await User.findById(ceoId).lean() as any;
      if (ceoUser) {
        const ceoWs = await Workspace.findOne({
          type: "ceo",
          isDeleted: { $ne: true },
          createdBy: { $in: [ceoUser.name, ceoUser.email].filter(Boolean) }
        }).lean();
        if (ceoWs) {
          body.ownerWorkspaceId = String(ceoWs._id);
        }
      }
    }

    if (!body.ownerWorkspaceId && user.role === "admin") {
      const anyCeoWs = await Workspace.findOne({ type: "ceo", isDeleted: { $ne: true } }).lean();
      if (anyCeoWs) {
        body.ownerWorkspaceId = String(anyCeoWs._id);
      }
    }
  }

  const parsed = workspaceSchema.safeParse(body);
  if (!parsed.success) {
    return ApiResponse.validationError("Invalid payload", parsed.error.format());
  }

  const existing = await Workspace.findOne({
    name: { $regex: new RegExp(`^${parsed.data.name.trim()}$`, "i") },
    isDeleted: { $ne: true }
  });

  if (existing) {
    return ApiResponse.error("A workspace with this name already exists", 4009, 400);
  }

  const resolvedOwnerWorkspaceId = parsed.data.ownerWorkspaceId || null;

  const newWorkspace = await Workspace.create({
    name: parsed.data.name.trim(),
    code: parsed.data.code ? parsed.data.code.trim().toUpperCase() : "",
    type: parsed.data.type ?? "company",
    ownerWorkspaceId: resolvedOwnerWorkspaceId,
    description: parsed.data.description ? parsed.data.description.trim() : "",
    isActive: parsed.data.isActive ?? true,
    createdBy: user.name || user.email
  });

  const targetCeoIds: string[] = [];

  if (user.role === "ceo") {
    targetCeoIds.push(user.id);
  }

  if (user.role === "admin" && ceoId && ceoId !== "all" && ceoId.trim() !== "") {
    const ceoUser = await User.findById(ceoId).lean() as any;
    if (ceoUser && ceoUser.role === "ceo") {
      targetCeoIds.push(String(ceoUser._id));
    }
  }

  for (const cId of targetCeoIds) {
    const existingMembership = await WorkspaceMember.findOne({
      userId: cId,
      workspaceId: newWorkspace._id
    });
    if (!existingMembership) {
      await WorkspaceMember.create({
        userId: cId,
        workspaceId: newWorkspace._id,
        empID: "CEO",
        role: "ceo",
        status: "active",
        isActive: true
      });
    }
  }

  return ApiResponse.created(newWorkspace, "Company created successfully");
}
