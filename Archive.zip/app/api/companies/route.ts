import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import Workspace from "@/models/Workspace";
import mongoose from "mongoose";
import { workspaceSchema } from "@/lib/validation";
import { ApiResponse } from "@/lib/api-response";
import { authorizeApi } from "@/lib/api-auth";

export async function GET() {
  const auth = await authorizeApi(["authenticated"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  await connectToDatabase();
  let workspaceIds: string[] | null = null;

  if (user.role !== "admin") {
    const memberships = await mongoose.model("WorkspaceMember").find({
      userId: user.id,
      status: "active",
      isActive: true
    }).select("workspaceId").lean() as unknown as { workspaceId: mongoose.Types.ObjectId }[];
    
    workspaceIds = memberships.map(m => m.workspaceId.toString());
  }

  const filter: any = { isDeleted: { $ne: true }, type: { $ne: "ceo" } };
  
  if (user.role !== "admin") {
    filter.isActive = true;
    if (user.role === "ceo") {
      const ceoIdentifiers = [user.name, user.email].filter(Boolean);
      filter.$or = [
        { _id: { $in: workspaceIds || [] } },
        ...(ceoIdentifiers.length > 0 ? [{ createdBy: { $in: ceoIdentifiers } }] : [])
      ];
    } else if (workspaceIds) {
      filter._id = { $in: workspaceIds };
    }
  }

  const workspaces = await Workspace.find(filter)
    .sort({ name: 1 })
    .lean();

  return ApiResponse.success(workspaces, "Companies fetched successfully");
}

export async function POST(request: Request) {
  const auth = await authorizeApi(["admin", "ceo"]);
  if (!auth.authorized) return auth.response;
  const user = auth.user;

  await connectToDatabase();
  const body = await request.json();

  if ((body.type ?? "company") === "company" && (!body.ownerWorkspaceId || body.ownerWorkspaceId.trim() === "")) {
    if (user.role === "ceo") {
      const ceoOwnerWorkspace = await Workspace.findOne({
        type: "ceo",
        isDeleted: { $ne: true },
        createdBy: { $in: [user.name, user.email].filter(Boolean) }
      }).lean();

      if (ceoOwnerWorkspace) {
        body.ownerWorkspaceId = String(ceoOwnerWorkspace._id);
      } else {
        const newCeoWs = await Workspace.create({
          name: `${user.name || "CEO"} Owner Workspace`,
          type: "ceo",
          isActive: true,
          createdBy: user.name || user.email
        });
        body.ownerWorkspaceId = String(newCeoWs._id);
      }
    }
  }

  const parsed = workspaceSchema.safeParse(body);
  if (!parsed.success) {
    return ApiResponse.validationError("Invalid payload", parsed.error.format());
  }

  const existing = await Workspace.findOne({
    name: { $regex: new RegExp(`^${parsed.data.name.trim()}$`, "i") },
    isDeleted: { $ne: true }
  });

  if (existing) {
    return ApiResponse.error("A workspace with this name already exists", 4009, 400);
  }

  const workspace = await Workspace.create({
    name: parsed.data.name.trim(),
    code: parsed.data.code ? parsed.data.code.trim().toUpperCase() : "",
    type: parsed.data.type ?? "company",
    ownerWorkspaceId: parsed.data.ownerWorkspaceId || null,
    description: parsed.data.description ? parsed.data.description.trim() : "",
    isActive: parsed.data.isActive ?? true,
    createdBy: user.name || user.email
  });

  if (user.role === "ceo") {
    const existingMembership = await mongoose.model("WorkspaceMember").findOne({
      userId: user.id,
      workspaceId: workspace._id
    });
    if (!existingMembership) {
      await mongoose.model("WorkspaceMember").create({
        userId: user.id,
        workspaceId: workspace._id,
        empID: "CEO",
        role: "ceo",
        status: "active",
        isActive: true
      });
    }
  }

  return ApiResponse.created(workspace, "Workspace created successfully");
}
