import { redirect } from "next/navigation";
import { AppShell } from "@/components/layout/app-shell";
import { DashboardPageHeader } from "@/components/dashboard/ui";
import { TeamTypesManager } from "@/components/admin/team-types-manager";
import { getCurrentUser } from "@/lib/auth";

export default async function HodTeamTypesPage() {
  const user = await getCurrentUser();
  if (!user || (user.role !== "hod" && user.role !== "admin" && user.role !== "ceo")) {
    redirect("/login");
  }

  return (
    <AppShell title="Team Types" role={user.role}>
      <div className="space-y-6">
        <DashboardPageHeader
          eyebrow="Organization"
          title="Team Types"
          description="Manage team types for your assigned departments."
        />
        <TeamTypesManager />
      </div>
    </AppShell>
  );
}
