import { redirect } from "next/navigation";
import { AppShell } from "@/components/layout/app-shell";
import { DashboardPageHeader } from "@/components/dashboard/ui";
import { AdminUserList } from "@/components/admin/user-list";
import { CreateUserButton } from "@/components/admin/create-user-button";
import { getCurrentUser } from "@/lib/auth";

export default async function TopLevelUsersPage() {
  const user = await getCurrentUser();
  if (!user || (user.role !== "team_lead" && user.role !== "hod" && user.role !== "admin" && user.role !== "ceo")) {
    if (user?.role === "report_manager") redirect("/reports");
    redirect("/login");
  }

  return (
    <AppShell title="Users" role={user.role}>
      <div className="space-y-6">
        <DashboardPageHeader
          eyebrow="Team Access"
          title="Managed Users"
          description="Review and update the users that report to your team hierarchy."
          actions={<CreateUserButton />}
        />
        <AdminUserList
          endpoint="/api/report-manager/users"
          editBaseHref="/users"
          viewBaseHref="/users"
          reportBaseHref="/reports"
        />
      </div>
    </AppShell>
  );
}
