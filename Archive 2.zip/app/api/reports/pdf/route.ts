import { NextResponse } from "next/server";
import db from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildReportPdfBuffer } from "@/lib/pdf";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user || (user.role !== "team_lead" && user.role !== "report_manager" && user.role !== "hod" && user.role !== "admin" && user.role !== "ceo")) {
    return NextResponse.json({ success: false, message: "Forbidden" }, { status: 403 });
  }

  const url = new URL(request.url);
  const employeeId = url.searchParams.get("employeeId");

  const reports = employeeId ? await db.dailyReport.findMany({ where: { employeeId } }) : await db.dailyReport.findMany();

  const buffer = await buildReportPdfBuffer({
    title: "Daily Reports",
    generatedBy: user.name,
    summary: {
      totalEmployees: new Set(reports.map((report: any) => String(report.employeeId))).size,
      totalReports: reports.length,
      teamSummary: reports.reduce<Record<string, number>>((acc, report: any) => {
        acc[report.teamName] = (acc[report.teamName] ?? 0) + 1;
        return acc;
      }, {}),
      statusSummary: reports.reduce<Record<string, number>>((acc, report: any) => {
        acc[report.status] = (acc[report.status] ?? 0) + 1;
        return acc;
      }, {})
    },
    reports: reports.map((report: any) => ({
      name: report.name,
      teamName: report.teamName,
      reportType: report.reportType,
      attachmentLink: report.attachmentLink,
      dailyMeetingUpdate: report.dailyMeetingUpdate,
      completedWork: report.completedWork,
      pendingWork: report.pendingWork,
      blockers: report.blockers,
      requiredClarification: report.requiredClarification,
      status: report.status
    })),
    missingReports: []
  });

  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="daily-reports.pdf"`
    }
  });
}
